﻿using System;
using System.Collections.Generic;
using System.Text;

using Anolis.Core;
using Anolis.Core.Data;

namespace Anolis.Resourcer.CommandLine {
	
	public class BatchReport {
		
		private List<BatchReportFile> _files;
		
		
		public BatchReport() {
			_files = new List<BatchReportFile>();
		}
		
		public void AddResource(ResourceData data) {
			
			
			
		}
		
	}
	
	public class BatchReportFile {
		
		
		
	}
	
	public class BatchReportResource {
		
		
		
	}
	
}
